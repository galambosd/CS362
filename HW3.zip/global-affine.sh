#!/bin/bash

# $@ will pass all parameters you passed to the shell script to the python script below
python global.py $@
